import 'dart:async';
import 'package:android_id/android_id.dart';
import 'package:flutter/services.dart';
import 'package:ganderbal/MyProfile.dart';
import 'package:ganderbal/PatrollingHIstory.dart';
import 'package:ganderbal/TamperingLIstSreen.dart';
import 'maps.dart';
import 'package:workmanager/workmanager.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_exit_app/flutter_exit_app.dart';
import 'package:flutter/material.dart';
import 'package:ganderbal/RegisterPage.dart';
import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'ApiHandler.dart';
Timer? timer1;
class PatrollingTeam extends StatefulWidget {
  String? name;
  String? designation;
  String? station;
  PatrollingTeam(
      String? this.name,String? this.designation,String? this.station);
  @override
  State<PatrollingTeam> createState() => _PatrollingTeamState();
}
class _PatrollingTeamState extends State<PatrollingTeam> {
  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
    return
      PopScope(
        canPop: false,
        child: SafeArea(child:
        Scaffold(
          appBar: AppBar(
            backgroundColor: Color(0xff020527),
            actions: [
              IconButton(icon:Icon(Icons.notifications,color: Colors.white,),
                onPressed: (){},),
            SizedBox(width: 50,),
              IconButton(icon:Icon(Icons.power_settings_new,
                color: Colors.white,),onPressed: (){
                showDialog(
                barrierDismissible: false
                ,
                    context: context, builder: (context)
                =>
                Center(
                  child: Card(
                    child: Container(
                      height: 0.2*height,
                      width: 0.8*width,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Spacer(flex: 1,),
                            Text("Do you want to log out"),
                          Spacer(flex: 1,),
                          Row(
                            children: [
                              Spacer(flex: 1,),
                              ElevatedButton(onPressed: (){
                                Navigator.of(context).pop();
                              },
                                  child: Text("Cancel")),
                              Spacer(flex: 1,),
                              ElevatedButton(onPressed: ()async{
                                // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>PhonenumberPage()));
                                // await Hive.openBox("local");
                                // var box = Hive.box("local");
                                // final number=box.get("number");
                                // box.put("login", false);
                                // Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                                // await ApiHandler().resetNumber(number.toString(),position.latitude.toString(),position.longitude.toString());
                                // call this to exit app
                                FlutterExitApp.exitApp();
                              },
                                  child: Text("Log Out")),
                              Spacer(flex: 1,)
                            ],
                          ),
                            Spacer(flex: 1,)
                          ],
                        ),
                      ),
                    ),
                  ),
                )
                );
              },),
              SizedBox(width: 20,),
            ],
          ),
        backgroundColor: Colors.grey.shade300,
        extendBody: true,
        extendBodyBehindAppBar: false,
        resizeToAvoidBottomInset: false,
        bottomNavigationBar: Container(

          padding: EdgeInsets.all(2),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: (){
                  },
                    icon: Icon(Icons.home,size: 0.08*width,),color: Colors.white,),
                  Text("Home",style: TextStyle(color: Colors.white,fontSize:0.03*width,),),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: (){},
                    icon: Icon(Icons.explore_rounded,size: 0.08*width,),color: Colors.white,),
                  Text("Explore",style: TextStyle(color: Colors.white,fontSize:0.03*width,),)
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: ()async{
                    await Hive.openBox("local");
                    var boxx= Hive.box("local");
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context)=>
                            MyProfile(Name: boxx.get('Name'),
                                Designation: boxx.get('Designation'),
                                Station: boxx.get('Station'),
                                Enrol_Code: boxx.get('Enrol_Code'),
                                Thana_Code: boxx.get('Thana_Code'),
                                Mobile: boxx.get('Mobile'),
                                Parentage: boxx.get('Parentage'),
                                Email: boxx.get('Email'),
                                Address: boxx.get('Address'),
                                Zone: boxx.get('Zone'),
                                Enrolled_App: boxx.get('Enrolled_App'),
                                Role: boxx.get('Role'))
                    ));
                  },
                    icon: Icon(Icons.account_circle_sharp,size: 0.08*width,),
                    color: Colors.white,),
                  Text("Profile",style: TextStyle(color: Colors.white,fontSize:0.03*width,),)
                ],
              ),


            ],
          ),
          margin: EdgeInsets.only(right: 0.17*width,
              left: 0.17*width,bottom: 4,top: 10),
          decoration: BoxDecoration(
            color: Color(0xff020527),
            borderRadius: BorderRadius.circular(40),
          ),
          height: 0.095*height,
        ),
        body: Column(
          children: [
            Container(
              decoration: BoxDecoration(

              ),
              child: Image.asset("assets/header.png",height: 0.2*height,fit: BoxFit.fill,),
              width: width,
            ),
            Container(
              child:
              Center(child:
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Welcome:${this.widget.name}(${this.widget.designation})",style: TextStyle(color: Colors.white),),
                  Text("(${this.widget.station})",style: TextStyle(color: Colors.white),),
                  // Text("Welcome:${this.widget.name}(${this.widget.designation})",style: TextStyle(color: Colors.white),),
                  // Text("(${this.widget.station})",style: TextStyle(color: Colors.white),),
                ],
              )),
              height: 0.1*height,
              width: width,
            decoration: BoxDecoration(
              gradient:
              LinearGradient(colors: [Colors.blueAccent,Colors.green]),
            ),
            ),
                Container(
                  height: 0.5*height,
                  color: Colors.grey.shade300,
                  child: Column(
                    children: [
                      Spacer(flex: 1,),
                      Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            InkWell(
                          onTap: ()async{
                            await Hive.openBox("local");
                            var boxx= Hive.box("local");
                            if(boxx.get("patrolling")=="started")
                              Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (context)=>PausePatrolling(boxx.get("id"),timer1)));
                              else if(boxx.get("patrolling")=="paused")
                              Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (context)=>RestartPatrolling(boxx.get("id"),timer1)));
                                else
                            Navigator.of(context)
                                .push(MaterialPageRoute(builder: (context)=>StartPatrolling()));
                          }
                          ,
                              child: Card(
                                elevation: 20,
                                color: Color(0xff020527),
                                  child: Container(
                                height: 0.1*height,
                                width: 0.2*width,
                                padding: EdgeInsets.all(4),
                                  child: Image.asset(
                                    "assets/polic.png",fit: BoxFit.contain,),
                                )),
                            ),
                            Text("Patrolling")
                          ],
                        ),
                        Column(
                          children: [
                            Card(
                              elevation: 20,
                                child: Container(
                                  height: 0.1*height,
                                  width: 0.2*width,

                                  padding: EdgeInsets.all(5),
                                  child: Image.asset(
                                    "assets/file.png",fit: BoxFit.contain,),
                                ),
                                color: Color(0xff020527),),
                            Text("Compliance")
                          ],
                        ),
                        Column(
                          children: [
                            Card(elevation: 20,
                                color:  Color(0xff020527),
                                child: Container(
                                  height: 0.1*height,
                                  width: 0.2*width,

                                  padding: EdgeInsets.all(5),
                                  child: Image.asset(
                                                  "assets/cases.png",fit: BoxFit.contain,),
                                )),
                            Text("Cases")
                          ],
                        ),]),
                      Spacer(flex: 1,),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                InkWell(
                                  onTap: (){
                                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Mapss()));
                                  }
                                  ,
                                  child: Card(
                                      elevation: 20,
                                      color: Color(0xff020527), child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,
                                    padding: EdgeInsets.all(4),
                                    child: Image.asset(
                                      "assets/maps.png",fit: BoxFit.contain,),
                                  )),
                                ),
                                Text("Maps")
                              ],
                            ),
                            Column(
                              children: [
                                Card(
                                  elevation: 20,
                                  child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,

                                    padding: EdgeInsets.all(5),
                                    child: Image.asset(
                                      "assets/activitylog.png",color: Colors.white,fit: BoxFit.contain,),
                                  ),
                                  color: Color(0xff020527),),
                                Text("Report")
                              ],
                            ),
                            Column(
                              children: [
                                InkWell(
                              onTap: ()async{
                                showDialog(
                                barrierDismissible: false
                                ,
                                    context: context, builder: (context)=>
                                    Center(
                                      child:
                                      Card(
                                        child: Container(
                                            width: double.infinity,
                                            height: 160,
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius: BorderRadius.circular(20)
                                            ),
                                            child: Center(child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                CupertinoActivityIndicator(
                                                  radius: 20,
                                                  color: Colors.purple,
                                                ),
                                                Text("Sending message...")
                                              ],
                                            ))),
                                      ),
                                    )
                                );
                                await Hive.openBox("local");
                                var boxx= Hive.box("local");
                                Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                               final number= await ApiHandler().support(boxx.get("number"), position.latitude.toString(),position.longitude.toString(), boxx.get("token"));
                                launchUrlString("https://api.whatsapp.com/send?phone=$number&text=Hello I need support on DPL app1");
                                Navigator.of(context).pop();
                              }
                              ,
                                  child: Card(elevation: 20,
                                      color:  Color(0xff020527),
                                      child: Container(
                                        height: 0.1*height,
                                        width: 0.2*width,

                                        padding: EdgeInsets.all(5),
                                        child: Image.asset(
                                          "assets/support.png",fit: BoxFit.contain,),
                                      )),
                                ),
                                Text("Support")
                              ],
                            ),]),
                    Spacer(flex: 1,),
                    Column(
                      children: [
                        InkWell(
                      onTap: ()async{
                        showDialog(
                        barrierDismissible: false
                        ,
                            context: context, builder: (context)=>
                            Center(
                              child:
                              Card(
                                child: Container(
                                    width: 120,
                                    height: 120,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(20)
                                    ),
                                    child: Center(child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CupertinoActivityIndicator(
                                          radius: 20,
                                          color: Colors.purple,
                                        ),
                                        Text("Refreshing")
                                      ],
                                    ))),
                              ),
                            )
                        );
                        await Hive.openBox("local");
                        var boxx= Hive.box("local");
                        boxx.put("patrolling", "started");
                        Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                        await ApiHandler().refresh(boxx.get("number"), position.latitude.toString(), position.longitude.toString(), boxx.get("token"));
                        Navigator.of(context).pop();
                      }
                      ,
                          child: Card(
                              elevation: 20,
                              color: Color(0xff020527), child: Container(
                            height: 0.1*height,
                            width: 0.2*width,
                            padding: EdgeInsets.all(15),
                                child: Image.asset(
                                                "assets/refresh.png",color: Colors.white,fit: BoxFit.contain,),
                              )),
                        ),
                        Text("Refresh")
                      ],
                    ),
                      Spacer(flex: 1,)

                ],
            )
                )
          ],
        ),)
            ),
      );
  }
}
// class PatrollingTeam extends StatefulWidget {
//   String? name;
//   String? designation;
//   String? station;
//   PatrollingTeam(
//       String? this.name,String? this.designation,String? this.station);
//   @override
//   State<PatrollingTeam> createState() => _PatrollingTeamState();
// }
class HigherOfficials extends StatefulWidget {
  String? name;
  String? designation;
  String? station;
  HigherOfficials(
      String? this.name,String? this.designation,String? this.station);
  @override
  State<HigherOfficials> createState() => _HigherOfficialsState();
}

class _HigherOfficialsState extends State<HigherOfficials> {
  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
    return
      PopScope(
        canPop: false,
        child: SafeArea(child:
        Scaffold(
          appBar: AppBar(
            backgroundColor: Color(0xff020527),
            actions: [
              IconButton(icon:Icon(Icons.notifications,color: Colors.white,),
                onPressed: (){},),
              SizedBox(width: 50,),
              IconButton(icon:Icon(Icons.power_settings_new,
                color: Colors.white,),onPressed: (){
                showDialog(
                barrierDismissible: false
                ,
                    context: context, builder: (context)
                =>
                    Center(
                      child: Card(
                        child: Container(
                          height: 0.2*height,
                          width: 0.8*width,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Spacer(flex: 1,),
                                Text("Do you want to log out"),
                                Spacer(flex: 1,),
                                Row(
                                  children: [
                                    Spacer(flex: 1,),
                                    ElevatedButton(onPressed: (){
                                      Navigator.of(context).pop();
                                    },
                                        child: Text("Cancel")),
                                    Spacer(flex: 1,),
                                    ElevatedButton(onPressed: ()async{
                                      FlutterExitApp.exitApp();
                                    },
                                        child: Text("Log Out")),
                                    Spacer(flex: 1,)
                                  ],
                                ),
                                Spacer(flex: 1,)
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                );
              },),
              SizedBox(width: 20,),
            ],
          ),
          backgroundColor: Colors.grey.shade300,
          extendBody: true,
          extendBodyBehindAppBar: false,
          resizeToAvoidBottomInset: false,
          bottomNavigationBar:Container(

            padding: EdgeInsets.all(2),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: (){

                    },
                      icon: Icon(Icons.home,size: 0.08*width,),color: Colors.white,),
                    Text("Home",style: TextStyle(color: Colors.white,fontSize:0.03*width,),),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: (){},
                      icon: Icon(Icons.explore_rounded,size: 0.08*width,),color: Colors.white,),
                    Text("Explore",style: TextStyle(color: Colors.white,fontSize:0.03*width,),)
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: ()async{
                      await Hive.openBox("local");
                      var boxx= Hive.box("local");
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context)=>
                              MyProfile(Name: boxx.get('Name'),
                                  Designation: boxx.get('Designation'),
                                  Station: boxx.get('Station'),
                                  Enrol_Code: boxx.get('Enrol_Code'),
                                  Thana_Code: boxx.get('Thana_Code'),
                                  Mobile: boxx.get('Mobile'),
                                  Parentage: boxx.get('Parentage'),
                                  Email: boxx.get('Email'),
                                  Address: boxx.get('Address'),
                                  Zone: boxx.get('Zone'),
                                  Enrolled_App: boxx.get('Enrolled_App'),
                                  Role: boxx.get('Role'))
                      ));
                    },
                      icon: Icon(Icons.account_circle_sharp,size: 0.08*width,),
                      color: Colors.white,),
                    Text("Profile",style: TextStyle(color: Colors.white,fontSize:0.03*width,),)
                  ],
                ),


              ],
            ),
            margin: EdgeInsets.only(right: 0.17*width,
                left: 0.17*width,bottom: 4,top: 10),
            decoration: BoxDecoration(
              color: Color(0xff020527),
              borderRadius: BorderRadius.circular(40),
            ),
            height: 0.095*height,
          ),
          body: Column(
            children: [
              Container(
                decoration: BoxDecoration(

                ),
                child: Image.asset("assets/header.png",height: 0.2*height,fit: BoxFit.fill,),
                width: width,
              ),
              Container(
                child:
                Center(child:
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Welcome:${this.widget.name}(${this.widget.designation})",style: TextStyle(color: Colors.white),),
                    Text("(${this.widget.station})",style: TextStyle(color: Colors.white),),
                  ],
                )),
                height: 0.1*height,
                width: width,
                decoration: BoxDecoration(
                    gradient:
                    LinearGradient(colors: [Colors.blueAccent,Colors.green]),
                ),
              ),
              Container(
                  height: 0.5*height,
                  color: Colors.grey.shade300,
                  child: Column(
                    children: [
                      Spacer(flex: 1,),
                      Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: (){
                                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>TamperingListScreen()));
                              },
                              child: Column(
                                children: [
                                  Card(
                                      elevation: 20,
                                      color: Color(0xff020527), child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,
                                    padding: EdgeInsets.all(4),
                                    child: Image.asset(
                                      "assets/tracking.png",fit: BoxFit.contain,),
                                  )),
                                  Text("DeviceTampering",style: TextStyle(fontSize: 10),)
                                ],
                              ),
                            ),
                            Column(
                              children: [
                                Card(
                                  elevation: 20,
                                  child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,

                                    padding: EdgeInsets.all(5),
                                    child: Image.asset(
                                      "assets/remote.png",fit: BoxFit.contain,),
                                  ),
                                  color: Color(0xff020527),),
                                Text("Violations")
                              ],
                            ),
                            Column(
                              children: [
                                InkWell(
                                  child: Card(elevation: 20,
                                      color:  Color(0xff020527),
                                      child: Container(
                                        height: 0.1*height,
                                        width: 0.2*width,

                                        padding: EdgeInsets.all(5),
                                        child: Image.asset(
                                          "assets/cases.png",fit: BoxFit.contain,),
                                      )),
                                ),
                                Text("StealthMode")
                              ],
                            ),]),
                      Spacer(flex: 1,),
                      Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                InkWell(
                                  onTap: (){
                                    Navigator.of(context).push(
                                      MaterialPageRoute(builder:
                                          (context)
                                      =>Patrollinghistory()
                                    ));
                                  }
                                  ,
                                  child: Card(
                                      elevation: 20,
                                      color: Color(0xff020527), child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,
                                    padding: EdgeInsets.all(4),
                                    child: Image.asset(
                                      "assets/file.png",fit: BoxFit.contain,),
                                  )),
                                ),
                                Text("Patrolling History",style: TextStyle(
                                  fontSize: 10
                                ),)
                              ],
                            ),
                            Column(
                              children: [
                                Card(
                                  elevation: 20,
                                  child: Container(
                                    height: 0.1*height,
                                    width: 0.2*width,

                                    padding: EdgeInsets.all(5),
                                    child: Image.asset(
                                      "assets/report.png",fit: BoxFit.contain,),
                                  ),
                                  color: Color(0xff020527),),
                                Text("LiveTracking",style: TextStyle(
                                  fontSize: 13
                                ),)
                              ],
                            ),

                            Column(
                              children: [
                                Card(elevation: 20,
                                    color:  Color(0xff020527),
                                    child: Container(
                                      height: 0.1*height,
                                      width: 0.2*width,

                                      padding: EdgeInsets.all(5),
                                      child: Image.asset(
                                        "assets/assignment.png",fit: BoxFit.contain,),
                                    )),
                                Text("Report")
                              ],
                            ),]),
                      Spacer(flex: 1,),
                      Column(
                        children: [
                          InkWell(
                        onTap: ()async{
                          showDialog(
                          barrierDismissible: false
                          ,
                              context: context, builder: (context)=>
                              Center(
                                child:
                                Card(
                                  child: Container(
                                      width: double.infinity,
                                      height: 200,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(20)
                                      ),
                                      child: Center(child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          CupertinoActivityIndicator(
                                            radius: 20,
                                            color: Colors.purple,
                                          ),
                                          Text("Sending message...")
                                        ],
                                      ))),
                                ),
                              )
                          );
                          await Hive.openBox("local");
                          var boxx= Hive.box("local");
                          Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                          final number= await ApiHandler().support(boxx.get("number"), position.latitude.toString(),position.longitude.toString(), boxx.get("token"));
                          launchUrlString("https://api.whatsapp.com/send?phone=$number&text=Hello I need support on DPL app1");
                          Navigator.of(context).pop();
                          },
                            child: Card(
                                elevation: 20,
                                color: Color(0xff020527), child: Container(
                              height: 0.1*height,
                              width: 0.2*width,
                              padding: EdgeInsets.all(10),
                              child: Image.asset(
                                "assets/support.png",fit: BoxFit.contain,),
                            )),
                          ),
                          Text("Support")
                        ],
                      ),
                      Spacer(flex: 1,)

                    ],
                  )
              )
            ],
          ),

        )
        ),
      );
  }
}
/*
{
"posts": [
{
"ID": 1,
"param": "end_time",
"value": "23:00"
},
{
"ID": 2,
"param": "frequency",
"value": "30"
},
{
"ID": 3,
"param": "method",
"value": "Internet"
},
{
"ID": 4,
"param": "start_time",
"value": "15:00"
}
]
}*/

class StartPatrolling extends StatefulWidget {
  const StartPatrolling();
  @override
  State<StartPatrolling> createState() => _StartPatrollingState();
}

class _StartPatrollingState extends State<StartPatrolling> with WidgetsBindingObserver{
  Timer? timer;
  String kalyan="";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addObserver(this);

  }


  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
        return
        Scaffold(

          backgroundColor: Colors.white,
          body:Column(
            children: [
              Container(height: 0.6*height,width: width,
              child: Mapss(),
              ),
   Container(
                    decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xff064bb0),Color.fromARGB(225, 197, 108, 228)]),
                        color: Colors.white,
                    ),
                  padding: EdgeInsets.all(40),
                    child: Column(

                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ElevatedButton(onPressed: ()async{
                          showDialog(
                              barrierDismissible: false,
                              context: context, builder: (context)=>
                                  Center(
                                    child:
                                    Card(
                                      child: Container(
                                        width: 120,
                                          height: 120,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.circular(20)
                                          ),
                                          child: Center(child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              CupertinoActivityIndicator(
                                                radius: 20,
                                                color: Colors.purple,
                                              ),
                                              Text("Loading")
                                            ],
                                          ))),
                                    ),
                                  )
                          );

                          //
                          await Hive.openBox("local");
                          var boxx= Hive.box("local");
                          boxx.put("patrolling", "started");
                          Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                          final dateFormatter = DateFormat('yyyy-MM-dd');
                          final timeFormatter = DateFormat('HH:mm:ss');
                          final DateTime now = DateTime.now();

                          final formattedDate = dateFormatter.format(now);
                          final formattedTime = timeFormatter.format(now);
                          final finalresult=await ApiHandler().startPatrolling(boxx.get("number"), position.latitude.toString(),position.longitude.toString(),
                              boxx.get("token"),formattedTime,formattedDate);
                          print("patrol start");
                          print(finalresult);
                          Map<String,dynamic> status=await ApiHandler().check_status(boxx.get("number"),
                              position.latitude.toString(), position.longitude.toString(),
                              boxx.get("token").toString());
                          var method=await ApiHandler().getGpsInternet(boxx.get("number"),
                              position.latitude.toString(),position.longitude.toString(),
                              boxx.get("token"));
                          var frequency=ApiHandler().getFrequency(boxx.get("number"),
                              position.latitude.toString(),position.longitude.toString(),
                              boxx.get("token"));
                          const _androidIdPlugin = AndroidId();
                          final String? androidId = await _androidIdPlugin.getId();
                          boxx.put("id",status['sessionID'].toString());
                          Navigator.of(context).pop();
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (context)=>PausePatrolling(status['sessionID'].toString(),this.timer))
                          );

                          print(finalresult);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AwesomeSnackbarContent(
                            title: 'Started Patrolling!',
                            inMaterialBanner: true,
                            color: Colors.blue,
                            message:
                            'Patrolling!',
                            /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                            contentType: ContentType.success,
                          ),
                          ));
                          print("Frequency we got"+frequency.toString());
                          await Hive.openBox("local");
                          print("kalyannivi");
                          ///here ra bey


                        },
                            child:Text("Start Patrolling"))
                      ],
                    ),
                  height: 0.4*height,
                  width: width,
                ),
            ],
          ),
          bottomNavigationBar:Container(

            padding: EdgeInsets.all(2),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: (){
                      Navigator.of(context).pop();
                    },
                      icon: Icon(Icons.home,size: 0.04*height,),color: Colors.white,),
                    Text("Home",style: TextStyle(color: Colors.white,fontSize:0.015*height,),),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: (){},
                      icon: Icon(Icons.explore_rounded,size: 0.04*height,),color: Colors.white,),
                    Text("Explore",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(onPressed: ()async{
                      await Hive.openBox("local");
                      var boxx= Hive.box("local");
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context)=>
                            MyProfile(Name: boxx.get('Name'),
                                Designation: boxx.get('Designation'),
                                Station: boxx.get('Station'),
                                Enrol_Code: boxx.get('Enrol_Code'),
                                Thana_Code: boxx.get('Thana_Code'),
                                Mobile: boxx.get('Mobile'),
                                Parentage: boxx.get('Parentage'),
                                Email: boxx.get('Email'),
                                Address: boxx.get('Address'),
                                Zone: boxx.get('Zone'),
                                Enrolled_App: boxx.get('Enrolled_App'),
                                Role: boxx.get('Role'))
                      ));
                    },
                      icon: Icon(Icons.account_circle_sharp,size: 0.04*height,),
                      color: Colors.white,),
                    Text("Profile",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
                  ],
                ),


              ],
            ),
            margin: EdgeInsets.only(right: 0.17*width,
                left: 0.17*width,bottom: 4,),
            decoration: BoxDecoration(
              color: Color(0xff020527),
              borderRadius: BorderRadius.circular(40),
            ),
            height: 0.095*height,
          ) ,
          extendBody: true,
          extendBodyBehindAppBar: false,
        );
  }
}
class RestartPatrolling extends StatefulWidget {
  String? id;
  Timer? timer;
  RestartPatrolling(String? this.id,Timer? this.timer);
  @override
  State<RestartPatrolling> createState() => _RestartPatrollingState();
}

class _RestartPatrollingState extends State<RestartPatrolling> {
  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
    return   Scaffold(
      backgroundColor: Colors.white,
      body:Column(
        children: [
          Container(
            height: 0.5*height,
            width: width,
            child: Mapss(),
          ),
          Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Color(0xff064bb0),Color.fromARGB(225, 197, 108, 228)]),
                    color: Colors.white,
                ),
              padding: EdgeInsets.all(40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Spacer(flex: 1,),
                  Text("Session ID ${this.widget.id}"),
                  Spacer(flex: 1,),
                  ElevatedButton(
                      onPressed: ()async{
                        showDialog(
                        barrierDismissible: false
                        ,
                            context: context, builder: (context)=>
                            Center(
                              child:
                              Card(
                                child: Container(
                                    width: 120,
                                    height: 120,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(20)
                                    ),
                                    child: Center(child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CupertinoActivityIndicator(
                                          radius: 20,
                                          color: Colors.purple,
                                        ),
                                        Text("Loading")
                                      ],
                                    ))),
                              ),
                            )
                        );
                        await Hive.openBox("local");
                        var boxx= Hive.box("local");
                        Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                        final dateFormatter = DateFormat('yyyy-MM-dd');
                        final timeFormatter = DateFormat('HH:mm:ss');
                        final DateTime now = DateTime.now();
                        final formattedDate = dateFormatter.format(now);
                        final formattedTime = timeFormatter.format(now);
                        final finalresult=await ApiHandler().startPatrolling(boxx.get("number"), position.latitude.toString(),position.longitude.toString(),
                            boxx.get("token"),formattedTime,formattedDate);
                        setState(() {
                        });
                        boxx.put("patrolling", "restarted");
                        Navigator.of(context).pop();
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AwesomeSnackbarContent(
                          inMaterialBanner: true,
                          title:  'Patrolling Restarted!',
                          color: Colors.red,
                          titleFontSize: 13,
                          message:
                          'Patrolling Restarted!',
                          /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                          contentType: ContentType.success,

                        ),
                        ));
                        Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (context)=>PausePatrolling(this.widget.id,this.widget.timer))
                        );
                      },
                      child:Text("Restart Patrolling")),
                  Spacer(flex: 1,),
                  ElevatedButton(onPressed: ()async{
                    showDialog(
                    barrierDismissible: false
                    ,
                        context: context, builder: (context)=>
                        Center(
                          child:
                          Card(
                            child: Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(20)
                                ),
                                child: Center(child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CupertinoActivityIndicator(
                                      radius: 20,
                                      color: Colors.purple,
                                    ),
                                    Text("Loading")
                                  ],
                                ))),
                          ),
                        )
                    );
                    await Hive.openBox("local");
                    var boxx= Hive.box("local");
                    boxx.put("patrolling", "completed");
                    print("aklayn");
                    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                    print("godav");
                    final dateFormatter = DateFormat('yyyy-MM-dd');
                    final timeFormatter = DateFormat('HH:mm:ss');
                    final DateTime now = DateTime.now();
                    final formattedDate = dateFormatter.format(now);
                    final formattedTime = timeFormatter.format(now);
                    boxx.put("kalyan","stop");
                    print("kalyan ram is 789");
                    final finalresult=await ApiHandler().completePatrolling(boxx.get("number"), position.latitude.toString(),position.longitude.toString(),
                        boxx.get("token"),formattedTime,formattedDate);
                    Navigator.of(context).pop();
                    Navigator.of(context).pop();
                    print(finalresult);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AwesomeSnackbarContent(
                      inMaterialBanner: true,
                      title:  'Patrolling Accomplished!',
                      color: Colors.green,
                      titleFontSize: 13,
                      message:
                      'Patrolling Accomplished!',
                      /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                      contentType: ContentType.success,
                    ),
                    ));

                  },
                      child:Text("Complete Patrolling")),
                  Spacer(flex: 6,),
                ],
              ),
              height: 0.5*height,
              width: width,
            ),
        ],
      ),
      bottomNavigationBar: Container(

        padding: EdgeInsets.all(2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: (){
                  Navigator.of(context).pop();
                },
                  icon: Icon(Icons.home,size: 0.04*height,),color: Colors.white,),
                Text("Home",style: TextStyle(color: Colors.white,fontSize:0.015*height,),),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: (){},
                  icon: Icon(Icons.explore_rounded,size: 0.04*height,),color: Colors.white,),
                Text("Explore",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: ()async{
                  await Hive.openBox("local");
                  var boxx= Hive.box("local");
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context)=>
                          MyProfile(Name: boxx.get('Name'),
                              Designation: boxx.get('Designation'),
                              Station: boxx.get('Station'),
                              Enrol_Code: boxx.get('Enrol_Code'),
                              Thana_Code: boxx.get('Thana_Code'),
                              Mobile: boxx.get('Mobile'),
                              Parentage: boxx.get('Parentage'),
                              Email: boxx.get('Email'),
                              Address: boxx.get('Address'),
                              Zone: boxx.get('Zone'),
                              Enrolled_App: boxx.get('Enrolled_App'),
                              Role: boxx.get('Role'))
                  ));
                },
                  icon: Icon(Icons.account_circle_sharp,size: 0.04*height,),
                  color: Colors.white,),
                Text("Profile",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
              ],
            ),


          ],
        ),
        margin: EdgeInsets.only(right: 0.17*width,
            left: 0.17*width,bottom: 4,top: 10),
        decoration: BoxDecoration(
          color: Color(0xff020527),
          borderRadius: BorderRadius.circular(40),
        ),
        height: 0.095*height,
      ),
      extendBody: true,

      extendBodyBehindAppBar: false,
    );
  }
}

class PausePatrolling extends StatefulWidget {
  String? id;
  Timer? timer;
  PausePatrolling(String? this.id,Timer? this.timer);
  @override
  State<PausePatrolling> createState() => _PausePatrollingState();
}

class _PausePatrollingState extends State<PausePatrolling> {
 bool pause=true;
  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
    return   Scaffold(

      extendBody: true,
      extendBodyBehindAppBar: false,
      backgroundColor: Colors.white,
      body:Column(
        children: [
          Container(
            height: 0.5*height,
            width: width,
            child: Mapss(),
          ),
          Container(                        decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xff064bb0),Color.fromARGB(225, 197, 108, 228)]),
                color: Colors.white,
              ),
              padding: EdgeInsets.all(40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Spacer(flex: 1,),
                  Text("Session ID ${this.widget.id}"),
                  Spacer(flex: 1,),
                  ElevatedButton(
                      onPressed: ()async{
                        showDialog(
                        barrierDismissible: false
                        ,
                            context: context, builder: (context)=>
                            Center(
                              child:
                              Card(
                                child: Container(
                                    width: 120,
                                    height: 120,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(20)
                                    ),
                                    child: Center(child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CupertinoActivityIndicator(
                                          radius: 20,
                                          color: Colors.purple,
                                        ),
                                        Text("Loading")
                                      ],
                                    ))),
                              ),
                            )
                        );
                        await Hive.openBox("local");
                        var boxx= Hive.box("local");
                        Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                        final dateFormatter = DateFormat('yyyy-MM-dd');
                        final timeFormatter = DateFormat('HH:mm:ss');
                        final DateTime now = DateTime.now();
                        final formattedDate = dateFormatter.format(now);
                        final formattedTime = timeFormatter.format(now);
                        final finalresult=await ApiHandler().pausePatrolling(boxx.get("number"), position.latitude.toString(),position.longitude.toString(),
                            boxx.get("token"),formattedTime,formattedDate);
                        setState(() {
                          pause=false;
                        });
                        Navigator.of(context).pop();
                        boxx.put("patrolling", "paused");
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AwesomeSnackbarContent(
                          inMaterialBanner: true,
                          title:  'Patrolling Paused!',
                          color: Colors.red,
                          titleFontSize: 13,
                          message:
                          'Patrolling Paused!',
                          /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                          contentType: ContentType.success,

                        ),
                        ));
                        Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context)=>RestartPatrolling(this.widget.id,this.widget.timer)
                    ));
                  },
                      child:Text("Pause Patrolling")),
                  Spacer(flex: 1,),
                  ElevatedButton(onPressed: ()async{
                    showDialog(
                    barrierDismissible: false
                    ,
                        context: context, builder: (context)=>
                        Center(
                          child:
                          Card(
                            child: Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(20)
                                ),
                                child: Center(child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CupertinoActivityIndicator(
                                      radius: 20,
                                      color: Colors.purple,
                                    ),
                                    Text("Loading")
                                  ],
                                ))),
                          ),
                        )
                    );
                    print("kalyan ram called here");
                    await Hive.openBox("local");
                    var boxx= Hive.box("local");
                    boxx.put("patrolling","completed");
                    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
                    final dateFormatter = DateFormat('yyyy-MM-dd');
                    final timeFormatter = DateFormat('HH:mm:ss');
                    final DateTime now = DateTime.now();
                    final a="";
                    final formattedDate = dateFormatter.format(now);
                    final formattedTime = timeFormatter.format(now);
                    print("kalyan ram called here");
                    final finalresult=await ApiHandler().completePatrolling(boxx.get("number"), position.latitude.toString(),position.longitude.toString(),
                        boxx.get("token"),formattedTime,formattedDate);
                    print("maneesh teja");
                    Navigator.of(context).pop();
                    print(finalresult);
                    Navigator.of(context).pop();
                    timer1!.cancel();
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AwesomeSnackbarContent(
                      inMaterialBanner: true,

                      title:  'Patrolling Accomplished!',
                      color: Colors.green,
                      titleFontSize: 13,
                      message:
                      'Patrolling Accomplished!',
                      /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                      contentType: ContentType.success,
                    ),
                    ));
                  },
                      child:Text("Complete Patrolling")),
                  Spacer(flex: 3,),
                ],
              ),
              height: 0.5*height,
              width: width,
            ),
        ],

      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: (){
                  Navigator.of(context).pop();
                },
                  icon: Icon(Icons.home,size: 0.04*height,),color: Colors.white,),
                Text("Home",style: TextStyle(color: Colors.white,fontSize:0.015*height,),),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: (){},
                  icon: Icon(Icons.explore_rounded,size: 0.04*height,),color: Colors.white,),
                Text("Explore",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: ()async{
                  await Hive.openBox("local");
                  var boxx= Hive.box("local");
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context)=>
                          MyProfile(Name: boxx.get('Name'),
                              Designation: boxx.get('Designation'),
                              Station: boxx.get('Station'),
                              Enrol_Code: boxx.get('Enrol_Code'),
                              Thana_Code: boxx.get('Thana_Code'),
                              Mobile: boxx.get('Mobile'),
                              Parentage: boxx.get('Parentage'),
                              Email: boxx.get('Email'),
                              Address: boxx.get('Address'),
                              Zone: boxx.get('Zone'),
                              Enrolled_App: boxx.get('Enrolled_App'),
                              Role: boxx.get('Role'))
                  ));
                },
                  icon: Icon(Icons.account_circle_sharp,size: 0.04*height,),
                  color: Colors.white,),
                Text("Profile",style: TextStyle(color: Colors.white,fontSize:0.015*height,),)
              ],
            ),


          ],
        ),
        margin: EdgeInsets.only(right: 0.17*width,
            left: 0.17*width,bottom: 4,top: 10),
        decoration: BoxDecoration(
          color: Color(0xff020527),
          borderRadius: BorderRadius.circular(40),
        ),
        height: 0.095*height,
      ),

    );
  }
}
