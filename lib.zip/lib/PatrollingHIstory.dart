import 'dart:convert';
import 'package:android_id/android_id.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;

class Patrollinghistory extends StatefulWidget {
  const Patrollinghistory({super.key});

  @override
  State<Patrollinghistory> createState() => _PatrollinghistoryState();
}
class _PatrollinghistoryState extends State<Patrollinghistory> {
  Future<List<Map<String, dynamic>>> fetchPatrollingHistory() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    const _androidIdPlugin = AndroidId();
    final String? androidId = await _androidIdPlugin.getId();
    await Hive.openBox("local");
    var boxx= Hive.box("local");
    final uri = Uri.parse(
        "https://api1.aksasoft.net/patr_dplganderbal/webservices/view_patr_histoty.php?id=${androidId.toString()}&lat=${position.latitude}&long1=${position.longitude}&token=${boxx.get("token")}&passcode=97786068765874&fingerprint=biometric123&mobile=${boxx.get("number")}&accuracy=${position.accuracy}&type=Live");
    https://api1.aksasoft.net/patr_dplganderbal/webservices/view_patr_histoty.php?id=22b07af2da90aa5c&lat=82&long1=11&token=H5LQ4qEeHu0Ayurd&passcode=97786068765874&fingerprint=biometric123&mobile=8360971662&accuracy=10&type=Live
    final response = await http.get(uri);
    print("final result"+response.body.toString());
      final List<Map<String,dynamic>> posts = jsonDecode(response.body)["posts"];
      print("posts"+posts.toString());
      print("kalyan");
      return posts.map((post) => post as Map<String, dynamic>).toList();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Patrolling History"),
      ),
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black), // Color for the border
          ),
          margin: const EdgeInsets.all(10),
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: fetchPatrollingHistory(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              }  else if (snapshot.hasData) {
                final data = snapshot.data!;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final patrollingHistory = data[index];
                    return Container(
                      width: MediaQuery.of(context).size.width, // Set width to match screen width
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: [
                            DataColumn(label: Text("Session_ID")),
                            DataColumn(label: Text("Patrolling_ID")),
                            DataColumn(label: Text("Started")),
                            DataColumn(label: Text("Concluded")),
                            DataColumn(label: Text("Status")),
                          ],
                          rows: [
                            DataRow(
                              cells: [
                                DataCell(Text(patrollingHistory['Session_ID'].toString())),
                                DataCell(Text(patrollingHistory['Patrolling_ID'].toString())),
                                DataCell(Text(patrollingHistory['Started'].toString())),
                                DataCell(Text(patrollingHistory['Concluded'].toString())),
                                DataCell(Text(patrollingHistory['Status'].toString())),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              } else {
                return Center(child: Text("Empty"),);
              }
            },
          ),
        ),
      ),
    );
  }

}

// class Patrollinghistory extends StatefulWidget {
//   const Patrollinghistory({super.key});
//
//   @override
//   State<Patrollinghistory> createState() => _PatrollinghistoryState();
// }
//
// class _PatrollinghistoryState extends State<Patrollinghistory> {
//   Future<List<Map<String,dynamic>>> returnn()async{
//
//     List<Map<String,dynamic>> listt=[{"kalyan":9},{"kalyan":9},{"kalyan":9},{"kalyan":9},];
//     await Future.delayed(Duration(seconds: 2));
//     return listt;
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Patrolling history"),
//       ),
//       body: Center(
//         child: Container(
//           margin: EdgeInsets.all(10),
//           child: FutureBuilder(
//               future: returnn(),
//               builder: (c,s){
//                 if(s.hasData){
//                   return
//                     ListView.builder(
//                       itemCount: s.data!.length,
//                       itemBuilder: (context,index)=> Container(padding: EdgeInsets.all(10),
//                         child: DataTable(
//                           columns: [DataColumn(label:Text( "")),DataColumn(label:Text(""))],
//                           rows: [DataRow(cells: [
//                             DataCell(Text("Session_ID")),
//                             DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                             DataRow(cells: [
//                               DataCell(Text("Patrolling_IO")),
//                               DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                             DataRow(cells: [
//                               DataCell(Text("Timestamp")),
//                               DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                             DataRow(cells: [
//                               DataCell(Text("Status")),
//                               DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                             DataRow(cells: [
//                               DataCell(Text("Violation")),
//                               DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                             DataRow(cells: [
//                               DataCell(Text("Violation_Param")),
//                               DataCell(Text(s.data![index]['kalyan'].toString()))]),
//                           ],
//                           decoration: BoxDecoration(
//                               color: Colors.yellow,
//                               border: BorderDirectional(
//                                 bottom: BorderSide(
//                                     color: Colors.black
//                                 ),
//                                 top: BorderSide(
//                                     color: Colors.black
//                                 ),
//                                 start : BorderSide(
//                                     color: Colors.black
//                                 ),
//                                 end: BorderSide(
//                                     color: Colors.black
//                                 ),
//
//                               )
//                           ),
//                         ),
//                       ),
//                     );}
//                 else return CircularProgressIndicator();
//               }
//           ),
//         ),
//       ),
//     );
//   }
// }
