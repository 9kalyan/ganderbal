import 'package:flutter/material.dart';
import 'package:flutter/material.dart';

class MyProfile extends StatelessWidget {
  final String Name;
  final String Designation;
  final String Station;
  final String Enrol_Code;
  final String Thana_Code;
  final String Mobile;
  final String Parentage;
  final String Email;
  final String Address;
  final String Zone;
  final String Enrolled_App;
  final String Role;


  MyProfile({
    required this.Name,
    required this.Designation,
    required this.Station,
    required this.Enrol_Code,
    required this.Thana_Code,
    required this.Mobile,
    required this.Parentage,
    required this.Email,
    required this.Address,
    required this.Zone,
    required this.Enrolled_App,
    required this.Role,
  });
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Police Data'),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: <DataColumn>[
            DataColumn(label: Text('Field')),
            DataColumn(label: Text('Value')),
          ],
          rows: <DataRow>[
            DataRow(cells: <DataCell>[
              DataCell(Text('Enrol_Code')),
              DataCell(Text(this.Enrol_Code)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Thana_Code')),
              DataCell(Text(this.Thana_Code)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Station')),
              DataCell(Text(this.Station)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Name')),
              DataCell(Text(this.Name)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Designation')),
              DataCell(Text(this.Designation)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Mobile')),
              DataCell(Text(this.Mobile)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Parentage')),
              DataCell(Text(this.Parentage)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Email')),
              DataCell(Text(this.Email)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Address')),
              DataCell(Text(this.Address)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Zone')),
              DataCell(Text(this.Zone)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Enrolled_App')),
              DataCell(Text(this.Enrolled_App)),
            ]),
            DataRow(cells: <DataCell>[
              DataCell(Text('Role')),
              DataCell(Text(this.Role)),
            ]),
          ],
        ),
      ),
    );
  }
}

